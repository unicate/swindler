Eidg. Geb�ude- und Wohnungsregister GWR (Bundesamt f�r Statistik) 9.1 / Registre f�d�ral des b�timents et des logements RegBL (Office f�d�ral de la statistique) 9.1

[DE] Direkte Downloads GWR im Format CSV 
Ganze Schweiz (Modell 4.1): https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/CH/CH.zip
Ganze Schweiz (Modell 3.7): https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/CH/CH37.zip
Kantonale oder kommunale Teil-Downloads Liste: https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/meta.txt

[FR] T�l�chargement direct RegBL au format CSV:
Toute la Suisse (Mod�le 4.1): https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/CH/CH.zip 
Toute la Suisse (Mod�le 3.7): https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/CH/CH37.zip
T�l�chargements partiels (canton ou commune) liste: https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/meta.txt

[IT] Scaricamento diretto REA al formato CSV:
Tutta la Svizzera (Modello 4.1): https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/CH/CH.zip 
Tutta la Svizzera (Modello 3.7): https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/CH/CH37.zip
Scaricamenti parziali (Cantone ou Commune) lista: https://data.geo.admin.ch/ch.bfs.gebaeude_wohnungs_register/CSV/meta.txt
